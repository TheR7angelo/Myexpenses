CREATE VIEW v_total as
    SELECT h.compte, round(sum(h.montant), 2) as restant
    FROM v_historique h
    GROUP BY h.compte;

