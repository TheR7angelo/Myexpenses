CREATE VIEW v_total_by_categorie as
    Select h.compte, h.categorie, round(sum(h.montant), 2) as montant
    FROM v_historique h
    GROUP BY h.compte, h.categorie;

